# 🌟 LUMINA // Next-Gen Digital Product & Experience Studio

A modern, ultra-responsive, award-winning website template engineered with HTML5, modern CSS3, and vanilla ES6+ JavaScript. Designed with meticulous attention to typography, micro-interactions, dark/light aesthetics, and web performance.

---

## 🚀 Quick Start

### Option 1: Instant Browser View (Zero Dependencies)
Simply open [`index.html`](file:///C:/Users/Biman%20Choudhury/.gemini/antigravity/scratch/lumina-agency-website/index.html) in any modern browser (Google Chrome, Microsoft Edge, Mozilla Firefox, Safari, Brave):
- Double-click `index.html`, or
- Drag and drop `index.html` into an open browser window.

### Option 2: Run Local Web Server
You can launch the built-in, zero-dependency PowerShell HTTP server:
```powershell
cd "C:\Users\Biman Choudhury\.gemini\antigravity\scratch\lumina-agency-website"
powershell -ExecutionPolicy Bypass -File .\serve.ps1 -Port 8080
```
Then visit: `http://localhost:8080`

---

## 🎨 Key Features & Architecture

### 1. Visual Aesthetics & Design System
- **Dark & Light Mode Switcher**: Seamless theme toggle with CSS variable tokens and `localStorage` persistence.
- **Glassmorphism & Depth**: Multi-layer blurred glass surfaces (`backdrop-filter`), glowing gradient borders, and soft shadows.
- **Dynamic Mouse Glow Spotlight**: Subtle interactive radial spotlight that glides across cards and sections.
- **Curated Typography**: Paired with *Plus Jakarta Sans* (headings) and *Inter* (body text) via Google Fonts.

### 2. Website Sections
1. **Header & Navigation**:
   - Sticky blur navbar with scroll detection.
   - Dynamic top scroll progress bar.
   - Fully responsive mobile drawer menu with smooth transition and link auto-close.
   - Theme toggle (Sun / Moon) and "Start a Project" CTA.
2. **Hero Section**:
   - Voted #1 Studio live status badge with animated pulse.
   - High-impact headline with gradient text clip.
   - Dual action CTAs ("Explore Featured Work", "Book a Strategy Call").
   - Live floating metrics cards ("+340% Conversion", "24 Design Awards").
   - Client social proof avatars with 5-star rating summary.
3. **Partner Brand Ticker**:
   - Infinite smooth scrolling logo strip (Stripe, Linear, Vercel, Figma, OpenAI, Supabase, Airbnb).
4. **Stats Counter Strip**:
   - Dynamic number counters triggered by `IntersectionObserver` on scroll ($150M+ Capital, 320+ Projects, 99.6% Retention, 24 Awards).
5. **About Us Section**:
   - Studio vision, mission, and 12+ years experience badge.
   - 4 Core Pillars: Agile Sprints, Enterprise Security, Sub-Second Speed, Universal Responsiveness.
   - Interactive Milestones Timeline (2020, 2022, 2024, 2026).
6. **Services & Products**:
   - 6 detailed cards: Custom Web Apps, UI/UX Design Systems, Mobile Apps, AI & Intelligent Interfaces, Cloud DevOps, SEO & CRO.
7. **Interactive Features Showcase**:
   - Interactive feature tabs with live preview display screen switching.
8. **4-Step Velocity Blueprint**:
   - Discovery, Prototyping, Agile Engineering, and Launch & Scale.
9. **Portfolio & Filterable Gallery**:
   - Category filter pills: All, Web Development, AI & SaaS, Mobile Apps, Brand & 3D.
   - 6 rich project case studies.
   - Full-screen interactive case study modal with project metrics, deliverables, and client endorsements.
10. **Testimonials Carousel**:
    - Star ratings, executive quotes, client avatars, and titles.
    - Autoplay with pause-on-hover, prev/next controls, dot indicators, and mobile touch swipe.
11. **Pricing & Engagement Models**:
    - 3 transparent tiers: Product Sprint MVP, Full-Scale Platform (Featured), Enterprise Dedicated.
12. **Interactive FAQ Accordion**:
    - Smooth expand/collapse answers addressing timelines, IP ownership, tech stack, and support.
13. **Contact Us Section**:
    - Direct contact info cards, live availability indicator ("🟢 Accepting Q1/Q2 Projects").
    - Validated interactive form with real-time feedback, interactive budget selector chips, and animated submit button.
    - Toast notification alert upon transmission.
14. **Footer**:
    - Newsletter subscription box with real-time feedback.
    - Categorized links and social media channels.
    - Back-to-Top smooth floating action button.

---

## 📁 File Structure

```
lumina-agency-website/
├── index.html          # Semantic HTML5 markup, accessibility ARIA, SEO meta tags
├── serve.ps1           # Zero-dependency PowerShell HTTP server
├── README.md           # Documentation & customization guide
├── css/
│   └── styles.css      # Design tokens, themes (dark/light), animations, responsive CSS
├── js/
│   └── main.js         # Modular interactive engine, carousel, modals, form validation
└── assets/
    └── favicon.svg     # Modern gradient SVG favicon
```

---

## 🛠️ Customization Guide

- **Colors & Branding**: Edit `:root` and `[data-theme="light"]` in [`css/styles.css`](file:///C:/Users/Biman%20Choudhury/.gemini/antigravity/scratch/lumina-agency-website/css/styles.css) to modify primary, secondary, and accent colors.
- **Projects & Case Studies**: Open [`js/main.js`](file:///C:/Users/Biman%20Choudhury/.gemini/antigravity/scratch/lumina-agency-website/js/main.js) and update the `projectDetails` dictionary to add or edit portfolio case studies.
- **Form Endpoints**: In [`js/main.js`](file:///C:/Users/Biman%20Choudhury/.gemini/antigravity/scratch/lumina-agency-website/js/main.js), replace the simulated `setTimeout` in `initContactForm()` with an API call to Formspree, Resend, or your backend server.
