/**
 * LUMINA DIGITAL STUDIO — Interactive Engine
 * Production-ready modular JavaScript
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Initialize Components
  initTheme();
  initHeaderAndScroll();
  initMobileNav();
  initMouseSpotlight();
  initCounters();
  initMilestones();
  initFeatures();
  initPortfolioFilter();
  initTestimonialCarousel();
  initFAQ();
  initContactForm();
  initNewsletter();
  initModals();
  initBackToTop();
  initActiveNavOnScroll();
});

/* ==========================================================================
   1. Theme Management (Dark / Light)
   ========================================================================== */
function initTheme() {
  const themeToggleBtn = document.getElementById('theme-toggle');
  if (!themeToggleBtn) return;

  const currentTheme = localStorage.getItem('lumina-theme') || 'dark';
  document.documentElement.setAttribute('data-theme', currentTheme);
  updateThemeIcon(currentTheme);

  themeToggleBtn.addEventListener('click', () => {
    const activeTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = activeTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('lumina-theme', newTheme);
    updateThemeIcon(newTheme);
    showToast(`Switched to ${newTheme === 'dark' ? 'Dark' : 'Light'} Mode`, 'info');
  });
}

function updateThemeIcon(theme) {
  const iconWrap = document.getElementById('theme-icon');
  if (!iconWrap) return;
  if (theme === 'dark') {
    // Show Sun icon to switch to light
    iconWrap.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="5"></circle>
        <line x1="12" y1="1" x2="12" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="23"></line>
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
        <line x1="1" y1="12" x2="3" y2="12"></line>
        <line x1="21" y1="12" x2="23" y2="12"></line>
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
      </svg>
    `;
    iconWrap.setAttribute('title', 'Switch to Light Mode');
  } else {
    // Show Moon icon to switch to dark
    iconWrap.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
      </svg>
    `;
    iconWrap.setAttribute('title', 'Switch to Dark Mode');
  }
}

/* ==========================================================================
   2. Header & Scroll Progress
   ========================================================================== */
function initHeaderAndScroll() {
  const header = document.getElementById('main-header');
  const progressBar = document.getElementById('scroll-progress');

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    
    // Header Blur on Scroll
    if (scrollY > 40) {
      header?.classList.add('scrolled');
    } else {
      header?.classList.remove('scrolled');
    }

    // Progress Bar Calculation
    if (progressBar) {
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = docHeight > 0 ? (scrollY / docHeight) * 100 : 0;
      progressBar.style.width = `${progress}%`;
    }
  }, { passive: true });
}

/* ==========================================================================
   3. Mobile Navigation Drawer
   ========================================================================== */
function initMobileNav() {
  const openBtn = document.getElementById('mobile-menu-toggle');
  const closeBtn = document.getElementById('drawer-close');
  const drawer = document.getElementById('mobile-drawer');
  const backdrop = document.getElementById('drawer-backdrop');
  const mobileLinks = document.querySelectorAll('.mobile-nav-link');

  function openDrawer() {
    drawer?.classList.add('active');
    backdrop?.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer() {
    drawer?.classList.remove('active');
    backdrop?.classList.remove('active');
    document.body.style.overflow = '';
  }

  openBtn?.addEventListener('click', openDrawer);
  closeBtn?.addEventListener('click', closeDrawer);
  backdrop?.addEventListener('click', closeDrawer);

  mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
      closeDrawer();
    });
  });
}

/* ==========================================================================
   4. Interactive Mouse Spotlight
   ========================================================================== */
function initMouseSpotlight() {
  const spotlight = document.getElementById('mouse-spotlight');
  if (!spotlight || window.innerWidth < 1024) return;

  let mouseX = 0, mouseY = 0;
  let currentX = 0, currentY = 0;

  window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  }, { passive: true });

  function animate() {
    // Smooth lerp
    currentX += (mouseX - currentX) * 0.12;
    currentY += (mouseY - currentY) * 0.12;
    spotlight.style.transform = `translate(${currentX}px, ${currentY}px)`;
    requestAnimationFrame(animate);
  }
  requestAnimationFrame(animate);
}

/* ==========================================================================
   5. Animated Stats Number Counters
   ========================================================================== */
function initCounters() {
  const counterElements = document.querySelectorAll('.stat-number');
  if (!counterElements.length) return;

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  counterElements.forEach(el => observer.observe(el));
}

function animateCounter(el) {
  const target = parseFloat(el.getAttribute('data-target') || '0');
  const prefix = el.getAttribute('data-prefix') || '';
  const suffix = el.getAttribute('data-suffix') || '';
  const isDecimal = target % 1 !== 0;
  const duration = 2000;
  const startTime = performance.now();

  function updateCount(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // EaseOutExpo curve
    const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
    const currentValue = easeProgress * target;

    if (isDecimal) {
      el.textContent = `${prefix}${currentValue.toFixed(1)}${suffix}`;
    } else {
      el.textContent = `${prefix}${Math.floor(currentValue)}${suffix}`;
    }

    if (progress < 1) {
      requestAnimationFrame(updateCount);
    } else {
      el.textContent = `${prefix}${target}${suffix}`;
    }
  }

  requestAnimationFrame(updateCount);
}

/* ==========================================================================
   6. Milestones / About Tabs
   ========================================================================== */
function initMilestones() {
  const tabButtons = document.querySelectorAll('.milestone-tab-btn');
  const tabContents = document.querySelectorAll('.milestone-content');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetYear = btn.getAttribute('data-tab');

      tabButtons.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetContent = document.getElementById(`milestone-${targetYear}`);
      if (targetContent) {
        targetContent.classList.add('active');
      }
    });
  });
}

/* ==========================================================================
   7. Feature Tabs
   ========================================================================== */
function initFeatures() {
  const featureTabs = document.querySelectorAll('.feature-tab-item');
  const previewImg = document.getElementById('feature-preview-img');
  const previewTitle = document.getElementById('feature-preview-title');
  const previewDesc = document.getElementById('feature-preview-desc');

  const featureData = {
    'speed': {
      img: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1000&q=80',
      title: 'Sub-Second Performance & Edge Caching',
      desc: 'Our enterprise stack leverages global CDN edge networks, streaming SSR, and micro-optimized asset delivery to guarantee Core Web Vitals 99+ on all viewports.'
    },
    'design': {
      img: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1000&q=80',
      title: 'Pixel-Precision Design Systems',
      desc: 'Tailored Figma design tokens mapped directly to production code components. Fluid typography, seamless accessibility (WCAG AAA), and custom micro-animations.'
    },
    'security': {
      img: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1000&q=80',
      title: 'Fortified Enterprise Architecture',
      desc: 'Zero-trust authentication, SOC-2 compliant practices, encrypted payload workflows, and proactive automated vulnerability audits.'
    },
    'scale': {
      img: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1000&q=80',
      title: 'Infinite Cloud Scalability',
      desc: 'Autonomous container autoscaling with Kubernetes and serverless backends engineered to handle viral traffic spikes without breaking a sweat.'
    }
  };

  featureTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      featureTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const featureKey = tab.getAttribute('data-feature');
      const data = featureData[featureKey];

      if (data && previewImg) {
        previewImg.style.opacity = '0.3';
        setTimeout(() => {
          previewImg.src = data.img;
          if (previewTitle) previewTitle.textContent = data.title;
          if (previewDesc) previewDesc.textContent = data.desc;
          previewImg.style.opacity = '1';
        }, 180);
      }
    });
  });
}

/* ==========================================================================
   8. Portfolio / Work Filters
   ========================================================================== */
function initPortfolioFilter() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const portfolioItems = document.querySelectorAll('.portfolio-item');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      portfolioItems.forEach(item => {
        const itemCategory = item.getAttribute('data-category');
        if (filterValue === 'all' || itemCategory === filterValue) {
          item.classList.remove('hidden');
          item.style.animation = 'fadeIn 0.4s ease forwards';
        } else {
          item.classList.add('hidden');
        }
      });
    });
  });
}

/* ==========================================================================
   9. Testimonials Carousel
   ========================================================================== */
function initTestimonialCarousel() {
  const slides = document.querySelectorAll('.testimonial-slide');
  const dots = document.querySelectorAll('.carousel-dot');
  const prevBtn = document.getElementById('prev-testimonial');
  const nextBtn = document.getElementById('next-testimonial');
  const carouselContainer = document.querySelector('.testimonial-carousel-wrap');

  if (!slides.length) return;

  let currentIndex = 0;
  let autoplayTimer = null;

  function goToSlide(index) {
    slides.forEach((slide, i) => {
      slide.classList.toggle('active', i === index);
    });
    dots.forEach((dot, i) => {
      dot.classList.toggle('active', i === index);
    });
    currentIndex = index;
  }

  function nextSlide() {
    const nextIndex = (currentIndex + 1) % slides.length;
    goToSlide(nextIndex);
  }

  function prevSlide() {
    const prevIndex = (currentIndex - 1 + slides.length) % slides.length;
    goToSlide(prevIndex);
  }

  function startAutoplay() {
    stopAutoplay();
    autoplayTimer = setInterval(nextSlide, 6000);
  }

  function stopAutoplay() {
    if (autoplayTimer) clearInterval(autoplayTimer);
  }

  nextBtn?.addEventListener('click', () => {
    nextSlide();
    startAutoplay();
  });

  prevBtn?.addEventListener('click', () => {
    prevSlide();
    startAutoplay();
  });

  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      goToSlide(index);
      startAutoplay();
    });
  });

  carouselContainer?.addEventListener('mouseenter', stopAutoplay);
  carouselContainer?.addEventListener('mouseleave', startAutoplay);

  // Touch Swipe Support
  let touchStartX = 0;
  let touchEndX = 0;

  carouselContainer?.addEventListener('touchstart', (e) => {
    touchStartX = e.changedTouches[0].screenX;
  }, { passive: true });

  carouselContainer?.addEventListener('touchend', (e) => {
    touchEndX = e.changedTouches[0].screenX;
    if (touchStartX - touchEndX > 45) {
      nextSlide();
    } else if (touchEndX - touchStartX > 45) {
      prevSlide();
    }
  }, { passive: true });

  startAutoplay();
}

/* ==========================================================================
   10. Interactive FAQ Accordion
   ========================================================================== */
function initFAQ() {
  const faqCards = document.querySelectorAll('.faq-card');

  faqCards.forEach(card => {
    const trigger = card.querySelector('.faq-trigger');
    trigger?.addEventListener('click', () => {
      const isOpen = card.classList.contains('open');

      // Close all other accordions for neat single-open behavior
      faqCards.forEach(otherCard => {
        if (otherCard !== card) {
          otherCard.classList.remove('open');
          otherCard.querySelector('.faq-trigger')?.setAttribute('aria-expanded', 'false');
        }
      });

      card.classList.toggle('open', !isOpen);
      trigger.setAttribute('aria-expanded', String(!isOpen));
    });
  });
}

/* ==========================================================================
   11. Contact Form with Validation & Budget Selection
   ========================================================================== */
function initContactForm() {
  const form = document.getElementById('contact-form');
  const budgetChips = document.querySelectorAll('.budget-chip');
  const selectedBudgetInput = document.getElementById('selected-budget');
  const submitBtn = document.getElementById('contact-submit-btn');

  // Budget Chips Select
  budgetChips.forEach(chip => {
    chip.addEventListener('click', () => {
      budgetChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      if (selectedBudgetInput) {
        selectedBudgetInput.value = chip.getAttribute('data-value') || '';
      }
    });
  });

  if (!form) return;

  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const serviceInput = document.getElementById('service-select');
  const messageInput = document.getElementById('message');

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function validateInput(input, condition) {
    if (condition) {
      input.classList.remove('is-invalid');
      input.classList.add('is-valid');
      return true;
    } else {
      input.classList.remove('is-valid');
      input.classList.add('is-invalid');
      return false;
    }
  }

  // Realtime blur / input listeners
  nameInput?.addEventListener('input', () => {
    validateInput(nameInput, nameInput.value.trim().length >= 2);
  });

  emailInput?.addEventListener('input', () => {
    validateInput(emailInput, validateEmail(emailInput.value.trim()));
  });

  messageInput?.addEventListener('input', () => {
    validateInput(messageInput, messageInput.value.trim().length >= 10);
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const isNameValid = validateInput(nameInput, nameInput.value.trim().length >= 2);
    const isEmailValid = validateInput(emailInput, validateEmail(emailInput.value.trim()));
    const isMessageValid = validateInput(messageInput, messageInput.value.trim().length >= 10);

    if (!isNameValid || !isEmailValid || !isMessageValid) {
      showToast('Please fix the errors in the highlighted fields.', 'error');
      return;
    }

    // Submit Loading State
    if (submitBtn) {
      submitBtn.disabled = true;
      const originalText = submitBtn.innerHTML;
      submitBtn.innerHTML = `
        <svg class="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10" stroke-opacity="0.25"></circle>
          <path d="M12 2a10 10 0 0 1 10 10" stroke-linecap="round"></path>
        </svg>
        <span>Transmitting Proposal...</span>
      `;

      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        form.reset();

        [nameInput, emailInput, serviceInput, messageInput].forEach(inp => {
          inp?.classList.remove('is-valid');
        });
        budgetChips.forEach(c => c.classList.remove('active'));

        showToast('Thank you! Your inquiry has been sent to our project directors. We will respond within 24 hours.', 'success');
      }, 1400);
    }
  });
}

/* ==========================================================================
   12. Newsletter Form
   ========================================================================== */
function initNewsletter() {
  const newsletterForm = document.getElementById('newsletter-form');
  const newsletterInput = document.getElementById('newsletter-email');

  newsletterForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = newsletterInput?.value.trim();

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showToast('Please enter a valid email address.', 'error');
      return;
    }

    newsletterInput.value = '';
    showToast('Subscribed! You will receive our monthly design & tech briefing.', 'success');
  });
}

/* ==========================================================================
   13. Modals (Portfolio Case Studies & Service Details)
   ========================================================================== */
const projectDetails = {
  'lumina-fintech': {
    title: 'Aura Capital — Global Wealth & Crypto Terminal',
    category: 'Fintech & Web Platform',
    year: '2026',
    client: 'Aura Capital International (London / Zurich)',
    duration: '14 Weeks',
    banner: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    overview: 'Aura Capital required an institutional-grade financial intelligence portal providing algorithmic portfolio rebalancing, millisecond order routing, and real-time biometric authorization.',
    metrics: [
      { label: 'Trading Volume', val: '$2.8B+' },
      { label: 'Latency Drop', val: '-64%' },
      { label: 'User Retention', val: '94.2%' }
    ],
    deliverables: ['Custom Next.js & WebGL Visualizer', 'Sub-50ms WebSocket Feed', 'Design System & Mobile App', 'SOC2 Security Architecture'],
    testimonial: '"Lumina built a platform so fluid and lightning-fast that our institutional trading volume doubled within three months of release."'
  },
  'nexus-ai': {
    title: 'CognitiveOS — Enterprise Multimodal AI Copilot',
    category: 'AI & SaaS Platform',
    year: '2026',
    client: 'Cognitive Dynamics (San Francisco)',
    duration: '16 Weeks',
    banner: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    overview: 'Designing and engineering an enterprise autonomous workflow engine that connects natural language prompts to multi-agent database orchestrations and document generation.',
    metrics: [
      { label: 'Weekly Active Users', val: '450K+' },
      { label: 'Task Automation', val: '87%' },
      { label: 'ARR Growth', val: '+410%' }
    ],
    deliverables: ['Streaming LLM Chat Architecture', 'Visual Workflow Canvas', 'Enterprise RBAC & Audit Trails', 'Dark/Light Design Tokens'],
    testimonial: '"The level of UI craftsmanship combined with deep technical rigor is something we have never experienced with any other agency."'
  },
  'chrono-luxury': {
    title: 'Verve & Co. — E-Commerce 3D Experience',
    category: 'E-Commerce & 3D Web',
    year: '2025',
    client: 'Verve Luxury Goods (Geneva)',
    duration: '10 Weeks',
    banner: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=80',
    overview: 'An ultra-luxury bespoke watch and jewelry shopping destination featuring real-time WebGL 3D product customization, custom engraving previews, and one-tap checkout.',
    metrics: [
      { label: 'Conversion Lift', val: '+52%' },
      { label: 'Average Order Value', val: '$3,400' },
      { label: 'Mobile Sales', val: '71%' }
    ],
    deliverables: ['Three.js 3D Configurator', 'Headless Shopify Architecture', 'Bespoke Brand Identity', 'Global Checkout Localization'],
    testimonial: '"Our customers are mesmerized by the 3D configurator. It set a completely new standard for luxury e-commerce."'
  },
  'zenith-health': {
    title: 'PulseBio — Predictive Telehealth & Wearable Ecosystem',
    category: 'Healthtech & Mobile',
    year: '2025',
    client: 'PulseBio Health Group (Boston)',
    duration: '18 Weeks',
    banner: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1200&q=80',
    overview: 'Cross-platform mobile and tablet application connecting Bluetooth ECG and glucose biosensors with predictive clinical dashboards and encrypted physician messaging.',
    metrics: [
      { label: 'Patients Monitored', val: '1.2M+' },
      { label: 'Diagnostic Accuracy', val: '99.4%' },
      { label: 'App Store Rating', val: '4.9 ★' }
    ],
    deliverables: ['HIPAA Compliant Mobile App (iOS/Android)', 'Bluetooth Low Energy Sync', 'Clinical Provider Dashboard', 'Continuous Vital Alerts'],
    testimonial: '"Lumina delivered a clean, reassuring medical UI that patients of all ages love, backed by zero-downtime reliability."'
  },
  'hyperion-cloud': {
    title: 'Strata Cloud — Developer Observability & DevOps',
    category: 'DevTools & Infrastructure',
    year: '2025',
    client: 'Strata Systems (Seattle)',
    duration: '12 Weeks',
    banner: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=80',
    overview: 'High-density telemetry dashboard displaying Kubernetes cluster metrics, distributed tracing graphs, and instant anomaly detection alerts.',
    metrics: [
      { label: 'Log Ingestion / Sec', val: '10M+' },
      { label: 'Incident Resolution', val: '3x Faster' },
      { label: 'Client Net Promoter', val: '78' }
    ],
    deliverables: ['High-Performance Canvas Graphing', 'CLI & Web UI Unification', 'OpenTelemetry Standard Adapters', 'Custom Keyboard Shortcuts'],
    testimonial: '"Engineers are notoriously picky about interfaces. Strata\'s UI is universally praised across our developer community."'
  },
  'astral-brand': {
    title: 'Omni Automotive — Autonomous EV Brand Launch',
    category: 'Brand Identity & Media',
    year: '2024',
    client: 'Omni Mobility (Stockholm)',
    duration: '8 Weeks',
    banner: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
    overview: 'Complete visual identity, bespoke 3D vehicle configurator, and international marketing launch platform for an electric supercar manufacturer.',
    metrics: [
      { label: 'Pre-Orders Received', val: '14,000+' },
      { label: 'Global Press Features', val: '220+' },
      { label: 'Site Traffic Launch Day', val: '3.4M' }
    ],
    deliverables: ['Complete Visual Identity & Typography', '3D Configurator Engine', 'Interactive Launch Keynote Site', 'Global Press Kit'],
    testimonial: '"The launch was an unprecedented success. Lumina brought our futuristic mobility vision to vivid life."'
  }
};

function initModals() {
  const modalOverlay = document.getElementById('project-modal');
  const modalCloseBtn = document.getElementById('modal-close');
  const modalImg = document.getElementById('modal-img');
  const modalCategory = document.getElementById('modal-cat');
  const modalYear = document.getElementById('modal-year');
  const modalTitle = document.getElementById('modal-title');
  const modalOverview = document.getElementById('modal-overview');
  const modalMetrics = document.getElementById('modal-metrics');
  const modalDeliverables = document.getElementById('modal-deliverables');
  const modalTestimonial = document.getElementById('modal-testimonial');

  // Open buttons
  const triggerBtns = document.querySelectorAll('[data-project-id]');
  triggerBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const projectId = btn.getAttribute('data-project-id');
      const project = projectDetails[projectId];
      if (!project || !modalOverlay) return;

      if (modalImg) modalImg.src = project.banner;
      if (modalCategory) modalCategory.textContent = project.category;
      if (modalYear) modalYear.textContent = project.year;
      if (modalTitle) modalTitle.textContent = project.title;
      if (modalOverview) modalOverview.textContent = project.overview;

      if (modalMetrics) {
        modalMetrics.innerHTML = project.metrics.map(m => `
          <div class="modal-metric-card">
            <div class="modal-metric-num">${m.val}</div>
            <div class="modal-metric-lbl">${m.label}</div>
          </div>
        `).join('');
      }

      if (modalDeliverables) {
        modalDeliverables.innerHTML = project.deliverables.map(d => `
          <li style="display:flex; align-items:center; gap:0.5rem; margin-bottom:0.5rem; font-size:0.925rem; color:var(--text-secondary);">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" color="var(--accent-emerald)"><polyline points="20 6 9 17 4 12"></polyline></svg>
            ${d}
          </li>
        `).join('');
      }

      if (modalTestimonial) {
        modalTestimonial.textContent = project.testimonial;
      }

      modalOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
  });

  function closeModal() {
    modalOverlay?.classList.remove('active');
    document.body.style.overflow = '';
  }

  modalCloseBtn?.addEventListener('click', closeModal);
  modalOverlay?.addEventListener('click', (e) => {
    if (e.target === modalOverlay) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalOverlay?.classList.contains('active')) {
      closeModal();
    }
  });
}

/* ==========================================================================
   14. Back to Top Button
   ========================================================================== */
function initBackToTop() {
  const backToTopBtn = document.getElementById('back-to-top');
  if (!backToTopBtn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      backToTopBtn.classList.add('visible');
    } else {
      backToTopBtn.classList.remove('visible');
    }
  }, { passive: true });

  backToTopBtn.addEventListener('click', () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
}

/* ==========================================================================
   15. Active Navigation Link on Scroll
   ========================================================================== */
function initActiveNavOnScroll() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');

  window.addEventListener('scroll', () => {
    const scrollPos = window.scrollY + 120;

    sections.forEach(sec => {
      const top = sec.offsetTop;
      const height = sec.offsetHeight;
      const id = sec.getAttribute('id');

      if (scrollPos >= top && scrollPos < top + height) {
        navLinks.forEach(link => {
          link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
        });
        mobileNavLinks.forEach(link => {
          link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
        });
      }
    });
  }, { passive: true });
}

/* ==========================================================================
   16. Toast Notification Helper
   ========================================================================== */
function showToast(message, type = 'success') {
  let toastContainer = document.getElementById('toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'toast-container';
    toastContainer.className = 'toast-container';
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let iconSvg = '';
  if (type === 'success') {
    iconSvg = `<svg class="toast-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
  } else if (type === 'error') {
    iconSvg = `<svg class="toast-icon" style="color:var(--accent-rose);" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`;
  } else {
    iconSvg = `<svg class="toast-icon" style="color:var(--accent-primary);" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
  }

  toast.innerHTML = `
    ${iconSvg}
    <span>${message}</span>
  `;

  toastContainer.appendChild(toast);

  // Trigger enter animation
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  // Auto remove
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      toast.remove();
    }, 350);
  }, 4200);
}
